from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import AdminLogin,CourseData,StudentRecord,BranchMaster
from studentapp.models import StudentReg
from employer.models import hrreg,PostJob

def adminlogin(request):
	if request.method == 'POST':
		if request.POST.get('log'):
			access = AdminLogin.objects.filter(Username=request.POST['txtuser'],Password=request.POST['txtpass'])
			if access.count()>0:
				return redirect(admindash)
			else:
				return render(request,'webadmin/adminlogin.html',{'invalid':'Invalid User Id or Password'})
	return render(request,'webadmin/adminlogin.html')

def admindash(request):
	approvals = StudentReg.objects.all()
	return render(request,'webadmin/adminhome.html',{'approvals':approvals})

def register(request):
	coursedata = CourseData.objects.all().order_by('Course_Name')
	branch = BranchMaster.objects.all().order_by('branch_name')
	if request.method == "POST":
		if request.POST.get('regbtn'):
			strecord = StudentRecord(Full_Name=request.POST['txtname'],Mobile=request.POST['txtmobile'],Email=request.POST['txtemail'],Course=request.POST['course'],
				Description=request.POST['description'],Branch=request.POST['txtbranch'],Passing_Year=request.POST['txtpassingyear'],Secondary_Percentage=request.POST['txtsec'],
				Higher_Secondary_Percentage=request.POST['txthigher-sec'],Graduation_Stream=request.POST['txtgraduation-stream'],Graduation_Percentage=request.POST['txtgraduation-percentage'],
				Post_Graduation_Stream=request.POST['txtpg-stream'],Post_Graduation_Percentage=request.POST['txtpg-percentage'],Other_Certification=request.POST['txtother-qualification'])

			strecord.save()
			return render(request,'webadmin/register.html',{'msg':"Form Submitted",'coursedata':coursedata,'branch':branch})
		elif request.POST.get('clearbtn'):
		
			return render(request,'webadmin/register.html',{'coursedata':coursedata,'branch':branch})
		

	return render(request,'webadmin/register.html',{'coursedata':coursedata,'branch':branch})


def showrecords(request):
	viewrecords = StudentRecord.objects.all()
	return render(request,'webadmin/showrecords.html',{'viewrecords':viewrecords})


def stuedit(request):	
	selectedstu = StudentRecord.objects.get(pk=request.GET['id'])
	if request.method=='POST':
		if request.POST.get('update'):
			selectedstu.Full_Name=request.POST['txtname']
			selectedstu.Mobile=request.POST['txtmobile']
			selectedstu.Email=request.POST['txtemail']
			selectedstu.Course=request.POST['txtcourse']
			selectedstu.Description=request.POST['txtarea']
			selectedstu.Branch=request.POST['txtbranch']
			selectedstu.Passing_Year=request.POST['txtpassing_year']
			selectedstu.Secondary_Percentage=request.POST['txtsecondarypercentage']
			selectedstu.Higher_Secondary_Percentage=request.POST['txthighsecondarypercentage']
			selectedstu.Graduation_Stream=request.POST['graduationstream']
			selectedstu.Graduation_Percentage=request.POST['graduationpercentage']
			selectedstu.Post_Graduation_Stream=request.POST['post-graduationstream']
			selectedstu.Post_Graduation_Percentage=request.POST['post-graduationpercentage']
			selectedstu.Other_Certification=request.POST['txtother-certification']
			selectedstu.save()
			return redirect(showrecords)
		else:
			return redirect(showrecords)

	return render(request,'webadmin/stuedit.html',{'stuedit':selectedstu})

def studel(request):
	selectedstu = StudentRecord.objects.get(pk=request.GET['id'])
	if request.method== 'POST':
		if request.POST.get('yes'):
			selectedstu.delete()
			return redirect(showrecords)
		else:
			return redirect(showrecords)
	return render(request,'webadmin/studel.html',{'data':selectedstu})

def coursemaster(request):
	if request.method =='POST':
		if request.POST.get('btn'):
			cd = CourseData(Course_ID=request.POST['courseid'], Course_Name=request.POST['coursename'])
			cd.save()
			return render(request,'webadmin/addcourse.html',{'success':"Technology Successfully Added"})
		else:
			return redirect('admindash')
	return render(request,'webadmin/addcourse.html')

def viewcourses(request):
	showcourses= CourseData.objects.all()
	return render(request,'webadmin/viewcourses.html',{'showcourses':showcourses})

def courseedit(request):
	cedit = CourseData.objects.get(pk=request.GET['id'])
	if request.method=='POST':
		if request.POST.get('update'):
			cedit.Course_ID = request.POST['courseid']
			cedit.Course_Name = request.POST['coursename']
			cedit.save()
			return render(request,'webadmin/cedit.html',{'cedit':cedit,"changes":"Changes Has Been Done"})
		else:
			return redirect('viewcourses')
	return render(request,'webadmin/cedit.html',{'cedit':cedit})

def deletecourse(request):
	cdelete = CourseData.objects.get(pk=request.GET['id'])
	if request.method =='POST':
		if request.POST.get('yes'):
			cdelete.delete()
			return redirect('viewcourses')
		else:
			return redirect('viewcourses')
	return render(request,'webadmin/cdelete.html',{'cdelete':cdelete})

def logout(request):
	return redirect('adminlogin')

def approve(request):
	
	status = request.GET['s']
	ID = request.GET['id']
	select = StudentReg.objects.get(pk=ID)
	select.Status=status
	select.save()
	
	return redirect('admindash')

def hrrequest(request):
	records = hrreg.objects.all()
	return render(request,'webadmin/hrrequest.html',{'records':records})

def hrapprove(request):
	st = request.GET['s']
	hr_by_id = request.GET['id']

	hr_record = hrreg.objects.get(pk=hr_by_id)
	hr_record.Status = st
	hr_record.save()

	return redirect('hrrequest')

def postjobapproval(request):
	post_job_data = PostJob.objects.all()
	return render(request,'webadmin/postjobapproval.html',{'post_job_data':post_job_data})

def jobstatus(request):
	st = request.GET['s']
	job_id =request.GET['id']
	find_posted_job = PostJob.objects.get(pk=job_id)
	find_posted_job.Status=st
	find_posted_job.save()
	return redirect('postjobapproval')

def ajaxdata(request):
	rec = request.GET['d']
	data = StudentReg.objects.filter(Email__contains=rec)

	return render(request,'webadmin/ajaxresult.html',{'data':data})

def stuapproveedit(request):
	#stuid = request.GET['q']
	#student = StudentReg.objects.filter(id=stuid)
	branch =BranchMaster.objects.all().order_by('branch_name')
	student = StudentReg.objects.filter(id=request.GET['q'])
	if request.method == 'POST':
		if request.POST.get('save'):
			select_id = request.POST['hiddenid']
			select_student = StudentReg.objects.get(id = select_id)
			select_student.Email = request.POST['txtemail']
			select_student.Branch =request.POST['txtbranch']
			select_student.Mobile =request.POST['txtmobile']
			select_student.Password = request.POST['txtpass']
			select_student.Status = request.POST['txtstatus']
			select_student.save()
			return redirect('admindash')
		elif request.POST.get('back'):
			return redirect('admindash')

	

	return render(request,'webadmin/stuapproveedit.html',{'student':student,'branch':branch})

def stuapprovedelete(request):
	student = StudentReg.objects.filter(id=request.GET['q'])
	if request.method == 'POST':
		if request.POST.get('yes'):
			student.delete()
			return redirect('admindash')
		elif request.POST.get('no'):
			return redirect('admindash')
	
def hrapproveedit(request):
	hrid = hrreg.objects.filter(pk=request.GET['q'])
	if request.method=='POST':
		if request.POST.get('save'):
			selected_hr = hrreg.objects.get(id=request.POST['hiddenid'])
			selected_hr.Full_Name = request.POST['txtfname']
			selected_hr.Company_Name = request.POST['txtcomname']
			selected_hr.Email = request.POST['txtemail']
			selected_hr.Password = request.POST['txtpass']
			selected_hr.Mobile = request.POST['txtmobile']
			selected_hr.Status = request.POST['txtstatus']
			selected_hr.save()
			return redirect('hrrequest')
		else:
			return redirect('hrrequest')
	return render(request,'webadmin/hrapproveedit.html',{'hrid':hrid})

def hrapprovedelete(request):
	hrid = hrreg.objects.filter(pk=request.GET['q'])
	if request.method =="POST":
		if request.POST.get('yes'):
			hrid.delete()
			return redirect('hrrequest')
		else:
			return redirect('hrrequest')
	
	return render(request,'webadmin/hrapprovedelete.html',{'hrid':hrid})

def hrajaxresult(request):
	d =  request.GET['q']
	hrdata = hrreg.objects.filter(Email__contains=d)
	return render(request,'webadmin/hrajaxresult.html',{'hrdata':hrdata})

def postjobdelete(request):
	d = request.GET['q']
	jobdata = PostJob.objects.filter(pk=d)
	if request.method == 'POST':
		if request.POST.get('yes'):
			jobdata.delete()
			return redirect('postjobapproval')
		else:
			return redirect('postjobapproval')
	return render(request,'webadmin/postjobdelete.html',{'jobdata':jobdata})

def postjobajaxresult(request):
	d =  request.GET['q']
	postjobdata = PostJob.objects.filter(Company_Name__contains=d)
	return render(request,'webadmin/postjobajaxresult.html',{'postjobdata':postjobdata})

def stuviewmore(request):
	viewmoreid =request.GET['id']
	studentdata = StudentRecord.objects.filter(id=viewmoreid)
	if request.method=='POST':
		return redirect('showrecords')
	return render(request,'webadmin/stuviewmore.html',{'studentdata':studentdata})

def recordsajaxresult(request):
	d = request.GET['q']
	data = StudentRecord.objects.filter(Full_Name__contains=d)

	return render(request,'webadmin/recordsajaxresult.html',{'data':data})