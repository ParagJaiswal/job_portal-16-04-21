from django.shortcuts import render
from employer.models import PostJob
import datetime

def index(request):
	return render(request,'guestapp/index.html')

def ajaxjob(request):
	detail = request.GET['v']
	jobs = PostJob.objects.filter(Technology__contains=detail)
	date = datetime.datetime.today()
	current_date = date.strftime("%F%d,%y")
	print(current_date)
	return render(request,'guestapp/loaddata.html',{'jobs':jobs,'current_date':current_date})
